package _01_Interfaces_EXEC._02_Multiple_Implementation;

public interface Identifiable {
    String id();
}
