package _01_Interfaces_EXEC._03_Ferrari;

interface  Car  {
    String model();
    String brakes();
    String gasPedal();
    String driveName();
}
