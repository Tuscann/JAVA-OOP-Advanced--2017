package _01_Interfaces_EXEC._09_Collection_Hierarchy;

public interface RemoveCollection extends  AddCollection {
    String remove();
}
