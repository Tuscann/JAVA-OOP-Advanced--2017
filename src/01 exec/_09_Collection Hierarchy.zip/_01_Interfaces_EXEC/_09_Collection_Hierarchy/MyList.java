package _01_Interfaces_EXEC._09_Collection_Hierarchy;

public interface MyList extends AddCollection,RemoveCollection {
    int used();
}
