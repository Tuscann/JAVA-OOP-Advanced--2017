package _01_Interfaces_EXEC._07_Food_Shortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
