package _01_Interfaces_EXEC._06_Birthday_Celebrations;

public class Robot implements Identificatable {

    private String model;
    private String id;

    Robot(String model, String id) {
        this.setModel(model);
        this.setId(id);
    }

    private void setModel(String model) {
        this.model = model;
    }

    private void setId(String id) {
        this.id = id;
    }


    @Override
    public String getBirthDate() {
        return this.id;
    }
}
