package _01_Interfaces_EXEC._06_Birthday_Celebrations;

public interface Identificatable {
    String getBirthDate();
}
