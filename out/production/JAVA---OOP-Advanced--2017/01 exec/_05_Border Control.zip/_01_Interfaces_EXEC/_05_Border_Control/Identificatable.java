package _01_Interfaces_EXEC._05_Border_Control;

public interface Identificatable {
    String getID();
}
