package _01_Interfaces_EXEC._08_Military_Elite.interfaces;

public interface Spy extends Soldier {
    int getCodeNumber();
}
