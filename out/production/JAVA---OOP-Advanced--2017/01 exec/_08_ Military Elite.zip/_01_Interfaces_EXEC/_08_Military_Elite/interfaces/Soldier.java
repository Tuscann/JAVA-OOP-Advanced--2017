package _01_Interfaces_EXEC._08_Military_Elite.interfaces;

public interface Soldier {
    int getId();
    String getName();
    String getLastName();
}
