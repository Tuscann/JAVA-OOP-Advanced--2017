package _01_Interfaces_EXEC._08_Military_Elite.interfaces;

public interface SpecialisedSoldier extends Private {
    String getCorps();
}
