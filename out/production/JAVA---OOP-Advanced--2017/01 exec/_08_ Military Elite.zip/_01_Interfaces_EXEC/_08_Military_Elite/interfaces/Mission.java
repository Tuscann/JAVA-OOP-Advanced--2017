package _01_Interfaces_EXEC._08_Military_Elite.interfaces;

public interface Mission {
    String getCodeName();
    String getState();

    void completeMission();
}
