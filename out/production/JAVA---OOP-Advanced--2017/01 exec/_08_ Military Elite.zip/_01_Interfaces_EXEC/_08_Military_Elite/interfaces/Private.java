package _01_Interfaces_EXEC._08_Military_Elite.interfaces;

public interface Private extends Soldier {
    double getSalary();
}
