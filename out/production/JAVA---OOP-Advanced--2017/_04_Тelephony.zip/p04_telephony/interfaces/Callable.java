package p04_telephony.interfaces;

public interface Callable {
    void call(String number);
}
