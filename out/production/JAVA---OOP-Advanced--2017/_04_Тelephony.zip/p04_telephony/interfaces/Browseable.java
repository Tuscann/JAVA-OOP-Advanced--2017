package p04_telephony.interfaces;

public interface Browseable {
    void browse(String website);
}
